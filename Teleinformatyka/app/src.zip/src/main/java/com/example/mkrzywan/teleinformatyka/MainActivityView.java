package com.example.mkrzywan.teleinformatyka;

import android.content.Context;

/**
 * Created by MKRZYWAN on 20.03.2016.
 */
public interface MainActivityView {

    Context getContext();
    void goToTheLivingRoomSettings();
}
