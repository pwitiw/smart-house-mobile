package com.example.mkrzywan.teleinformatyka;

/**
 * Created by MKRZYWAN on 20.03.2016.
 */
public enum AreaType {
    LIVING_ROOM, BATHROOM, BEDROOM, GARDEN;
}
