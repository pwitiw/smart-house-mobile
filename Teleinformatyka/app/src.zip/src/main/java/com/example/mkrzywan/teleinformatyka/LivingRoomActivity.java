package com.example.mkrzywan.teleinformatyka;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SwitchCompat;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.SeekBar;

public class LivingRoomActivity extends AppCompatActivity {

    private LivingRoomPresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_living_room);

        Intent intent = getIntent();
//        AreaStateController livingRoomController = intent.getExtras().
//                getParcelable(MainScreenActivity.LIVING_ROOM_CONTROLLER);

        boolean light = intent.getBooleanExtra(MainScreenActivity.LIGHT, false);
        boolean ventilation = intent.getBooleanExtra(MainScreenActivity.VENTILATION, false);
        int rollerBlindsIndex = intent.getIntExtra(MainScreenActivity.ROLLER_BLINDS, 0);
        AreaStateController livingRoomController = new AreaStateController
                (light, ventilation, RollerBlindsState.values()[rollerBlindsIndex]);

        presenter = new LivingRoomPresenter(livingRoomController);

        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        initialize();
    }

    public void initialize(){
        presenter.initializeLightSwitchCompat((SwitchCompat) findViewById(R.id.lr_light_switch));
        presenter.initializeVentilationSwitchCompat((SwitchCompat) findViewById(R.id.lr_ventilation_switch));
        presenter.initializeRollerBlindsSeekbar((SeekBar) findViewById(R.id.lr_roller_blinds_seekbar) );
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }
        else if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed(){
        Intent returnIntent = new Intent();
//        returnIntent.putExtra("result",presenter.getTemporaryState());
        returnIntent.putExtra(MainScreenActivity.LIGHT, presenter.getTemporaryState().isLight());
        returnIntent.putExtra(MainScreenActivity.VENTILATION, presenter.getTemporaryState().isVentilation());
        returnIntent.putExtra(MainScreenActivity.ROLLER_BLINDS, RollerBlindsState.
                getIndex(presenter.getTemporaryState().getRollerBlindsState()));
        setResult(Activity.RESULT_OK, returnIntent);
        finish();
    }
}
