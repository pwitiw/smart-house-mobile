package com.example.mkrzywan.teleinformatyka;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

public class MainScreenActivity extends AppCompatActivity implements MainActivityView{

    public static final int LIVING_ROOM_DATA = 0;
    public static final String LIGHT = "light";
    public static final String VENTILATION = "ventilation";
    public static final String ROLLER_BLINDS = "roller_blinds";
    public static final String LIVING_ROOM_CONTROLLER = "living_room_controller";


    MainScreenPresenter presenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        presenter = new MainScreenPresenter(this);
        initialize();
    }

    private void initialize(){
        presenter.initializeLivingRoomButton((Button) findViewById(R.id.living_room));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        if (id == android.R.id.home) {
            super.onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == LIVING_ROOM_DATA) {
            if (resultCode == RESULT_OK) {
                boolean light = data.getBooleanExtra(LIGHT, false);
                boolean ventilation = data.getBooleanExtra(VENTILATION, false);
                int rollerStateIndex = data.getIntExtra(ROLLER_BLINDS, 0);
//                AreaStateController livingRoomController = data.getExtras().getParcelable("result");
                AreaStateController livingRoomController = new AreaStateController
                        (light, ventilation, RollerBlindsState.values()[rollerStateIndex]);
                presenter.actualizeStatus(livingRoomController, AreaType.LIVING_ROOM);
                //TODO: here is the place to call presenter and actualize the backend
            }
        }
    }

    @Override
    public Context getContext() {
        return getApplicationContext();
    }

    @Override
    public  void goToTheLivingRoomSettings(){

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                Map<String, String> map = new HashMap<>();
                map.put("imie", "marta");
                presenter.httpHelper.sendJSON("http://demo9491701.mockable.io/", map);
            }
        });
        thread.run();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Intent livingRoomIntent = new Intent(MainScreenActivity.this, LivingRoomActivity.class);
//                livingRoomIntent.putExtra(LIVING_ROOM_CONTROLLER,
//                        presenter.buildingStateController.getLivingRoomController());
                AreaStateController lrController = presenter.buildingStateController.getLivingRoomController();
                livingRoomIntent.putExtra(LIGHT, lrController.isLight());
                livingRoomIntent.putExtra(VENTILATION, lrController.isVentilation());
                livingRoomIntent.putExtra(ROLLER_BLINDS, RollerBlindsState.getIndex(lrController.getRollerBlindsState()));
                startActivityForResult(livingRoomIntent, LIVING_ROOM_DATA);
            }
        });

    }
}
