package com.example.mkrzywan.teleinformatyka;

import android.support.v7.widget.SwitchCompat;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.SeekBar;

/**
 * Created by MKRZYWAN on 20.03.2016.
 */
public class LivingRoomPresenter {

    private SwitchCompat lightSwitchCompat;
    private SwitchCompat ventilationSwitchCompat;
    private SeekBar rollerBlindsSeekbar;

    public AreaStateController temporaryState;

    public LivingRoomPresenter(AreaStateController livingRoomController){
        this.temporaryState = livingRoomController;
    }

    public void initializeLightSwitchCompat(SwitchCompat lightSwitchCompat){
        this.lightSwitchCompat = lightSwitchCompat;
        this.lightSwitchCompat.setChecked(temporaryState.isLight());
        this.lightSwitchCompat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    temporaryState.turnLightOn();
                }
                else{
                    temporaryState.turnLightOff();
                }
            }
        });
    }

    public void initializeVentilationSwitchCompat(SwitchCompat ventilationSwitchCompat){
        this.ventilationSwitchCompat = ventilationSwitchCompat;
        this.ventilationSwitchCompat.setChecked(temporaryState.isVentilation());
        this.ventilationSwitchCompat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    temporaryState.turnVentilationOn();
                }
                else{
                    temporaryState.turnVentilationOff();
                }
            }
        });
    }

    public void initializeRollerBlindsSeekbar(SeekBar rollerBlindsSeekbar){
        this.rollerBlindsSeekbar = rollerBlindsSeekbar;
        this.rollerBlindsSeekbar.setProgress(RollerBlindsState.
                getIndex(temporaryState.getRollerBlindsState()));
        this.rollerBlindsSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                temporaryState.setRollerBlindsState(RollerBlindsState.values()[seekBar.getProgress()]);
            }
        });
    }

    public AreaStateController getTemporaryState() {
        return temporaryState;
    }
}
