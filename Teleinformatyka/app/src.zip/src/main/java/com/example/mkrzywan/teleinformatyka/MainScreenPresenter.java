package com.example.mkrzywan.teleinformatyka;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by MKRZYWAN on 19.03.2016.
 */
public class MainScreenPresenter {

    private Button goToLivingRoomSettingsBtn;
    private MainActivityView view;
    public static HttpHelper httpHelper;
    public static BuildingStateController buildingStateController;

    public MainScreenPresenter(MainActivityView view){
        this.view = view;
        httpHelper = new HttpHelper();
        buildingStateController = new BuildingStateController();
    }

    protected void initializeLivingRoomButton(Button goToLivingRoomSettingsBtn){
        this.goToLivingRoomSettingsBtn = goToLivingRoomSettingsBtn;
        this.goToLivingRoomSettingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view.goToTheLivingRoomSettings();
            }
        });
    }

    public void actualizeStatus(AreaStateController areaStateController, AreaType areaType){
        switch(areaType){
            case BATHROOM:
                buildingStateController.setBathroomController(areaStateController);
                break;
            case BEDROOM:
                buildingStateController.setBedroomController(areaStateController);
                break;
            case LIVING_ROOM:
                buildingStateController.setLivingRoomController(areaStateController);
                break;
            case GARDEN:
                buildingStateController.setGardenController(areaStateController);
                break;
        }
    }
}
