package com.example.mkrzywan.teleinformatyka;

import static com.example.mkrzywan.teleinformatyka.AreaType.BATHROOM;

/**
 * Created by MKRZYWAN on 20.03.2016.
 */
public class BuildingStateController {
    private AreaStateController bathroomController;
    private AreaStateController livingRoomController;
    private AreaStateController bedroomController;
    private AreaStateController gardenController;

    public BuildingStateController(){
        bathroomController = new AreaStateController();
        livingRoomController = new AreaStateController();
        bedroomController = new AreaStateController();
        gardenController = new AreaStateController();
    }

    public void turnLightOn(AreaType areaType){
        switch(areaType){
            case BATHROOM:
                bathroomController.turnLightOn();
                break;
            case BEDROOM:
                bedroomController.turnLightOn();
                break;
            case LIVING_ROOM:
                livingRoomController.turnLightOn();
                break;
            case GARDEN:
                gardenController.turnLightOn();
                break;
        }
    }

    public void turnLightOff(AreaType areaType){
        switch(areaType){
            case BATHROOM:
                bathroomController.turnLightOff();
                break;
            case BEDROOM:
                bedroomController.turnLightOff();
                break;
            case LIVING_ROOM:
                livingRoomController.turnLightOff();
                break;
            case GARDEN:
                gardenController.turnLightOff();
                break;
        }
    }

    public void turnVentilationOn(AreaType areaType){
        switch(areaType){
            case BATHROOM:
                bathroomController.turnVentilationOn();
                break;
            case BEDROOM:
                bedroomController.turnVentilationOn();
                break;
            case LIVING_ROOM:
                livingRoomController.turnVentilationOn();
                break;
            case GARDEN:
                gardenController.turnVentilationOn();
                break;
        }
    }

    public void turnVentilationOff(AreaType areaType){
        switch(areaType){
            case BATHROOM:
                bathroomController.turnVentilationOff();
                break;
            case BEDROOM:
                bedroomController.turnVentilationOff();
                break;
            case LIVING_ROOM:
                livingRoomController.turnVentilationOff();
                break;
            case GARDEN:
                gardenController.turnVentilationOff();
                break;
        }
    }

    public void fullOpenRollerBlinds(AreaType areaType){
        switch(areaType){
            case BATHROOM:
                bathroomController.fullOpenRollerBlinds();
                break;
            case BEDROOM:
                bedroomController.fullOpenRollerBlinds();
                break;
            case LIVING_ROOM:
                livingRoomController.fullOpenRollerBlinds();
                break;
            case GARDEN:
                gardenController.fullOpenRollerBlinds();
                break;
        }
    }

    public void semiOpenRollerBlinds(AreaType areaType){
        switch(areaType){
            case BATHROOM:
                bathroomController.semiOpenRollerBlinds();
                break;
            case BEDROOM:
                bedroomController.semiOpenRollerBlinds();
                break;
            case LIVING_ROOM:
                livingRoomController.semiOpenRollerBlinds();
                break;
            case GARDEN:
                gardenController.semiOpenRollerBlinds();
                break;
        }
    }

    public void closeRollerBlinds(AreaType areaType){
        switch(areaType){
            case BATHROOM:
                bathroomController.closeRollerBlinds();
                break;
            case BEDROOM:
                bedroomController.closeRollerBlinds();
                break;
            case LIVING_ROOM:
                livingRoomController.closeRollerBlinds();
                break;
            case GARDEN:
                gardenController.closeRollerBlinds();
                break;
        }
    }

    public AreaStateController getBathroomController() {
        return bathroomController;
    }

    public void setBathroomController(AreaStateController bathroomController) {
        this.bathroomController = bathroomController;
    }

    public AreaStateController getLivingRoomController() {
        return livingRoomController;
    }

    public void setLivingRoomController(AreaStateController livingRoomController) {
        this.livingRoomController = livingRoomController;
    }

    public AreaStateController getBedroomController() {
        return bedroomController;
    }

    public void setBedroomController(AreaStateController bedroomController) {
        this.bedroomController = bedroomController;
    }

    public AreaStateController getGardenController() {
        return gardenController;
    }

    public void setGardenController(AreaStateController gardenController) {
        this.gardenController = gardenController;
    }
}
