package com.example.mkrzywan.teleinformatyka;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by MKRZYWAN on 20.03.2016.
 */
public class AreaStateController implements Parcelable{

    //default values
    public boolean light = false;
    public boolean ventilation = false;
    public RollerBlindsState rollerBlindsState = RollerBlindsState.CLOSED;

    public AreaStateController(){}

    public AreaStateController(boolean light, boolean ventilation, RollerBlindsState rollerBlindsState) {
        this.light = light;
        this.ventilation = ventilation;
        this.rollerBlindsState = rollerBlindsState;
    }

    protected AreaStateController(Parcel in) {
        light = in.readByte() != 0;
        ventilation = in.readByte() != 0;
    }

    public static final Creator<AreaStateController> CREATOR = new Creator<AreaStateController>() {
        @Override
        public AreaStateController createFromParcel(Parcel in) {
            return new AreaStateController(in);
        }

        @Override
        public AreaStateController[] newArray(int size) {
            return new AreaStateController[size];
        }
    };

    public void turnLightOn(){
        light = true;
    }

    public void turnLightOff(){
        light = false;
    }

    public void turnVentilationOn(){
        ventilation = true;
    }

    public void turnVentilationOff(){
        ventilation = false;
    }

    public void fullOpenRollerBlinds(){
        rollerBlindsState = RollerBlindsState.OPEN;
    }

    public void semiOpenRollerBlinds(){
        rollerBlindsState = RollerBlindsState.SEMI_OPEN;
    }

    public void closeRollerBlinds(){
        rollerBlindsState = RollerBlindsState.CLOSED;
    }

    public boolean isLight() {
        return light;
    }

    public void setLight(boolean light) {
        this.light = light;
    }

    public boolean isVentilation() {
        return ventilation;
    }

    public void setVentilation(boolean ventilation) {
        this.ventilation = ventilation;
    }

    public RollerBlindsState getRollerBlindsState() {
        return rollerBlindsState;
    }

    public void setRollerBlindsState(RollerBlindsState rollerBlindsState) {
        this.rollerBlindsState = rollerBlindsState;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeBooleanArray(new boolean[] {this.light,
                this.ventilation});
        dest.writeString(rollerBlindsState.toString());
    }
}
